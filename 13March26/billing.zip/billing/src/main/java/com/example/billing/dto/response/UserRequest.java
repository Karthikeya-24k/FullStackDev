package com.example.billing.dto.response;

public class UserRequest {
    private String name;
    
    
}
