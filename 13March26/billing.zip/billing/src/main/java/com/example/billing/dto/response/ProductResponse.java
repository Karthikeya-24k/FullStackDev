package com.example.billing.dto.response;

public class ProductResponse {
    
}
